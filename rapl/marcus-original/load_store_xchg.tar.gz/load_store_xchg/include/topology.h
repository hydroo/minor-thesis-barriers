#ifndef TOPOLOGY_H
#define TOPOLOGY_H
#include "core.h"
#include <vector>
#include "thread.h"
#include "cachelevel.h"
#include <string>

#include <iostream>

class Topology
{
private:
	std::vector<int> cpustringToVector(std::string cpustring);
	std::vector<Thread*> threads;
	std::vector<Core*> cores;
	std::vector<Socket*> sockets;
	std::vector<CacheLevel* > cls;

	void attachThread(Thread* t);
	void attachCache(Cache* c);
public:
	Topology();
	virtual ~Topology();
	static std::vector<unsigned> fileToVector(std::string filename);
	static unsigned fileToUnsigned(std::string filename);

	Socket& getCurrentSocket();
	Thread& getCurrentThread();
	Core& getCurrentCore();

	template<typename T>
	void setAffinity(T& target) {
		cpu_set_t set;
		CPU_ZERO(&set);

		auto threads = target.getThreads();
		for (auto it = threads.begin(); it != threads.end(); it++) {
			Thread* tr = *it;
			CPU_SET(tr->getId(),&set);
		}

		if (pthread_setaffinity_np(pthread_self(),sizeof(cpu_set_t),&set))
			std::cerr << "Setting Affinity failed!" << std::endl;
	}

	template<typename T>
	void addAffinity(T& target) {
		cpu_set_t set;

		auto threads = target.getThreads();
		for (auto it = threads.begin(); it != threads.begin(); it++) {
			Thread* tr = *it;
			CPU_SET(tr->getId(),&set);
		}

		sched_setaffinity(0,sizeof(cpu_set_t),&set);
	}

	template<typename T>
	void removeAffinity(T& target) {
		cpu_set_t set;

		auto threads = target.getThreads();
		for (auto it = threads.begin(); it != threads.begin(); it++) {
			Thread* tr = *it;
			CPU_CLR(tr->getId(),&set);
		}

		sched_setaffinity(0,sizeof(cpu_set_t),&set);
	}

	std::vector<Thread *> &getThreads();
	std::vector<Socket *> &getSockets();
	std::vector<Core *> &getCores();
};

#endif // TOPOLOGY_H
