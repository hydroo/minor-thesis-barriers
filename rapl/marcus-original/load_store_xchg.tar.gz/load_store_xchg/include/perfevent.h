#ifndef PERFEVENT_H
#define PERFEVENT_H

#include <functional>
#include <cinttypes>
#include <vector>
#include <sys/time.h>
#include <linux/perf_event.h>

enum class PerfType { HARDWARE, CACHE, RAW, SOFTWARE };

class Event {
public:
	int config, config1, config2, type;
	Event(PerfType t, int cfg, int cfg1 = 0, int cfg2 = 0)
		: config(cfg), config1(cfg1), config2(cfg2) {
		switch (t) {
			case PerfType::HARDWARE: type = PERF_TYPE_HARDWARE; break;
			case PerfType::CACHE:	 type = PERF_TYPE_HW_CACHE; break;
			case PerfType::RAW:		 type = PERF_TYPE_RAW; break;
			case PerfType::SOFTWARE: type = PERF_TYPE_SOFTWARE; break;
		}
	}
};


class PerfEvent
{
protected:

	enum class ThrsType { VALUE, RATE, INTERVAL };
	enum class ThrsDirection { LOWER, HIGHER };

	struct notify_thrs{
		uint64_t thrs; //value or time
		uint64_t interval; //only used for interval type
		ThrsType type;
		ThrsDirection dir;
		std::function<void(PerfEvent*)> notifier; //function to call

		explicit notify_thrs(uint64_t interval, uint64_t next, std::function<void(PerfEvent*)> no)
			: thrs(next), interval(interval), type(ThrsType::INTERVAL), notifier(no) {}
		explicit notify_thrs(uint64_t th, ThrsType ty, ThrsDirection td,
							 std::function<void(PerfEvent*)> no) :
			thrs(th), interval(0), type(ty), dir(td), notifier(no) {}
	};

	std::vector<notify_thrs*> thresholds;

	uint64_t value;
	uint64_t rate;
	uint64_t lastTime; //ns

	perf_event_attr attr;
	int perf_fd;

	bool enabled;
	uint64_t last_value[3];
	uint64_t prev_value;

	void refreshValues();
	void checkThresholds();

public:
	//for the following listeners:
	//positive thresholds mean that it triggers when the limit is exceeded
	//negative thresholds mean that it triggers when the limit is undercut
	void notifyEventThresholdValue(int64_t threshold,std::function<void(PerfEvent*)> fkt);
	//rate in 1/s
	void notifyEventThresholdRate(int64_t threshold, std::function<void(PerfEvent *)> fkt);
	void notifyEventThresholdInterval(int64_t interval, std::function<void(PerfEvent *)> fkt);

	bool startMonitor();

	//returns the counter value, scaled for multiplexing
	uint64_t readCtr();
	//This returns the rate of the counter in samples/s since the last update
	uint64_t getRate();
	//reset the counter value tu 0
	void resetCtr();
	//enable/disable the counter. by default it is enabled by "startMonitor"
	void setEnabled(bool status);
	//get current counter state
	bool isEnabled();
	//% of the time that was actually measured
	float getConfidence();
	bool hasBeenMultiplexed();

	//This should be called directly by
	//the monitor. No need to call it by hand
	void update();

	PerfEvent(Event ev);
	virtual ~PerfEvent();

	//These are the generic hardware events that are present on all CPUs. More may be defined
	//in user headers / c files
};

class HWEvents {
  public:
	HWEvents() = delete;
	static const Event CPU_CYCLES;
	static const Event INSTRUCTIONS;
	static const Event CACHE_REFERENCES;
	static const Event CACHE_MISSES;
	static const Event BRANCH_INSTRUCTIONS;
	static const Event BRANCH_MISSES;
	static const Event BUS_CYCLES;
	static const Event STALLED_CYCLES_FRONTEND;
	static const Event STALLED_CYCLES_BACKEND;
	static const Event REF_CPU_CYCLES;
};

enum class CacheID { L1D, L1I, LastLevel, DTLB, ITLB, BPU, NODE }; // Node = all local caches!
enum class Operation { Read, Write, Prefetch };
enum class Result { Access, Miss };

class CacheEvent {
	public:
		CacheEvent() = delete;
		static Event create(CacheID t, Operation o, Result r);
};


#endif // PERFEVENT_H
