#ifndef SOCKET_H
#define SOCKET_H

class Socket;

#include "thread.h"
#include <vector>

class Socket
{
friend class Topology;
private:
	unsigned id;
	std::vector<Thread*> threads;
public:
	Socket(unsigned _id);
	void attachThread(Thread* t);
	unsigned getId();
	std::vector<Thread*> getThreads();
};

#endif // SOCKET_H
