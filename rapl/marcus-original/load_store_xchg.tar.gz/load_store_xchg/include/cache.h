#ifndef CACHE_H
#define CACHE_H

class Cache;

#include "cachelevel.h"
#include "cache.h"
#include "thread.h"
#include <ostream>
#include <vector>

typedef enum {
	DATA,
	INSTRUCTION,
	UNIFIED,
	UNKNOWN
} CacheType;

class Cache
{
friend class Topology;
friend std::ostream& operator<<(std::ostream&, const Cache&);
private:
	CacheLevel* lvl;
	unsigned reference_cpu;
	unsigned cache_index;

	unsigned level;
	unsigned sets;
	unsigned ways;
	unsigned lineSize;
	CacheType type;


	std::vector<unsigned> sharingThreadIDs;
	std::vector<Thread*> sharingThreads;

	void setLevel(CacheLevel* lvl);
	std::vector<unsigned> getSharingThreadIDs();
	void setSharingThreads(std::vector<Thread*> sharingThreads);
	unsigned getReferenceCPU();
public:
	unsigned getLevelNum();
	unsigned getSetsNum();
	CacheType getType();
	unsigned getWaysNum();
	unsigned getLineSize();
	unsigned getSize();
	Cache(unsigned cpu, unsigned index);
	std::vector<Thread*> &getSharingThreads();
};

#endif // CACHE_H
