#ifndef THREAD_H
#define THREAD_H

class Thread;

#include <vector>
#include "core.h"
#include "cache.h"
#include "socket.h"

class Thread
{
friend class Topology;
public:
	Thread(unsigned i);
	Socket* getSocket();
	Core* getCore();
	unsigned getId();

	std::vector<Thread*> &getThreads();

	std::vector<Cache *> &getCaches();
	std::vector<Core*> &getCoreSiblings();
	std::vector<Thread*> &getThreadSiblings();

private:
	unsigned id;
	unsigned socket_id;
	unsigned core_id;
	Socket* socket;
	Core* core;

	unsigned getCoreId();
	unsigned getSocketId();
	void setCore(Core* c);
	void setSocket(Socket* s);
	//Beware! Cache levels are from 0 - x! They do not start with level 1!
	void addCache(Cache* c);
	bool hasCache(Cache* c);

	std::vector<Cache*> cacheLevels;
	std::vector<Thread*> threadSiblings;
	std::vector<Core*> coreSiblings;
	std::vector<Thread*> threads;
	bool cs_init, ts_init;
};

#endif // THREAD_H
