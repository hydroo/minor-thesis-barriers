#ifndef MONITOR_H
#define MONITOR_H

#include "perfevent.h"
#include <functional>
#include <typeinfo>
#include <cstdint>
#include <pthread.h>
#include <vector>

class Monitor
{
private:

	uint64_t notify_ms; //notification interval in ms
	static void *run(void *ptr);
	void runThread();
	pthread_t thread;
	volatile uint64_t start_time;
	volatile uint64_t runs;
	bool simple_lock;
	std::vector<PerfEvent*> events;

public:
	//This gets a monitor for the current core. There may only
	//be one Monitor per Core!
	Monitor(uint64_t interval_ms);
	static Monitor& getMonitor();
	static std::vector<Monitor*> getMonitors();
	//
	void notifyEveryMs(int time, std::function<void(Monitor&)> fkt); //in ms

	//please be aware, that an intervall < 1ms may impact measurements
	//significantly! Please be also aware, that an intervall in the order of
	//minutes may lead to undetected overflows, if the event fires many times
	//per clock cycle
	void setIntervall(int ms); //ns = measurement interval
	bool startMonitor();
	void stopMonitor();
	void cancelMonitor();
	void addEvent(PerfEvent* ev);
};

#endif // MONITOR_H
