#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <iostream>
#include <cstdlib>
#include <cstdint>
#include <sys/time.h>
#include <pthread.h>
#include <sstream>
#include <cmath>
#include <ios>
#include <string.h>
#include <thread>

const static long long MHz = 1000000;

const static long long CPU_FREQ = 3300*MHz;
const static int NO_CPUs = 4;

volatile int start_barrier;
volatile int stop_barrier;
std::thread* threads[NO_CPUs];

static inline uint64_t rdtsc(void);
static inline uint64_t rdtsc(void)
{
    uint32_t a,d;
    asm volatile( "rdtsc\n" : "=a"(a), "=d"(d) );
    return static_cast<uint64_t>(d) << 32 | a;
}
				  
uint64_t readMSR(uint32_t msr) {
	uint64_t value;

	int fd = open("/dev/cpu/0/msr",O_RDONLY);
	if (fd < 0) {
		std::cerr << "Could not open msr file! " << strerror(errno) << std::endl;
		return ~0UL;
	}
	if (pread(fd,&value,sizeof value, msr) != sizeof value) {
		std::cerr << "Could not seek to msr 0x" << std::hex << msr << "!" << std::endl;
		return ~0UL;
	}
	close(fd);
	return value;
}

class Result {
public:
	double energy = 0;
	double energyPerBlock = 0;
	double time = 0;
	double timePerBlock = 0;
	double cyclesPerBlock = 0;
	double power = 0;
};

uint64_t raw = readMSR(0x606); //RAPl_POWER_UNIT
double energy = std::pow(0.5,(raw>>8) & 0x1F); //multiplier for unit

double getEnergy() {
	return readMSR(0x611)*energy; //611 = PGK / 639 = PP0 Energy 
}

static inline uint64_t gtod(void) {
	timeval tv;
	gettimeofday(&tv,NULL);
	return (tv.tv_sec*1000000L + tv.tv_usec);
}

void worker(int cpu, std::function<void (void)> func) {
  cpu_set_t cpuset;
  CPU_ZERO(&cpuset);
  CPU_SET(cpu, &cpuset);

  pthread_setaffinity_np(threads[cpu]->native_handle(),sizeof(cpu_set_t),&cpuset);
  
  asm volatile ("lock decl %0" : "+m" (start_barrier)::);
 
  while(start_barrier);
        
  func();
 
  asm volatile ("lock decl %0" : "+m" (stop_barrier)::);
  while(stop_barrier);
}

unsigned long long temp[0xFFFFF];

#define ASM_CODE_MULT(instr,loops,mult) do { unsigned long long *localTemp = new unsigned long long[mult]; asm volatile( "MOV $" #loops ",%%RCX;"\
			      "1: .rept (4096/" #mult ");" \
			      instr ";"\
			      ".endr; SUB $1,%%RCX; JNC 1b\n" \
			      : : "r" (&temp), "r"(localTemp): "rcx", "rax", "r8", "r9", "r10"); delete localTemp; } while(false); 
#define ASM_CODE(instr,loops) ASM_CODE_MULT(instr,loops,1)

inline void runAndJoin(int cpus, std::function<void (void)> func) {
  start_barrier = cpus;
  stop_barrier = cpus;
  
  for (intptr_t c = 0; c < cpus; c++) {
     threads[c] = new std::thread(worker,c,func);
   }
  
  for (unsigned int i = 0; i < cpus; i++) {
     threads[i]->join();
  }	
}
double pStatic = 0, pUncore = 0;

void setupWorkload() {
  double cpuE[4];
  uint64_t cpuT[4];
 
  double staticE = getEnergy();
  uint64_t staticT = gtod();

  sleep(5);

  staticE = getEnergy() - staticE;
  staticT = gtod() - staticT;

  pStatic = (staticE*1000000)/staticT;
  std::cout << "Static Power: " << pStatic << " W" << std::endl;
  double pFirstCore;
  double pAddCore = 0;
  
  for (int i = 0; i < NO_CPUs; i++) {
 
  	cpuE[i] = getEnergy();
	cpuT[i] = gtod();

  	runAndJoin(i+1,[] { ASM_CODE("XOR %%RAX,%%RAX",0xFFFFF); });
	
	cpuE[i] = getEnergy() - cpuE[i];
	cpuT[i] = gtod() - cpuT[i];
	if (i == 0) {
		pFirstCore = (cpuE[0]*1000000)/cpuT[0]-pStatic;
		std::cout << "First Core: " << pFirstCore << std::endl;
	} else {
		pAddCore += ((cpuE[i]*1000000)/cpuT[i])-(cpuE[i-1]*1000000)/cpuT[i];
		std::cout << "Add Core: " << ((cpuE[i]*1000000)/cpuT[i])-(cpuE[i-1]*1000000)/cpuT[i] << " => " << pAddCore << std::endl;
	}
  }
  pUncore = pFirstCore - pAddCore/(NO_CPUs-1);
  std::cout << "Uncore Power: " << pUncore << " W" << std::endl;


}

Result runWorkload(int cpus, std::function<void (void)> func, int iterations) {
  Result res;
  
  double totE  = getEnergy();
  uint64_t totT = gtod();

  runAndJoin(cpus,func);

  totE = getEnergy() - totE;
  totT = gtod() - totT;
  
  //Todo:: Remove uncore base power and static power!!;
  res.energy = totE;
  res.time = totT/1000000.0;
  res.energyPerBlock = (totE)/(iterations*4096.0*cpus);
  res.timePerBlock = (res.time)/(iterations*4096.0*cpus); 
  res.cyclesPerBlock = res.timePerBlock*CPU_FREQ;
  res.power = (totE/res.time-pUncore-pStatic)/cpus; //clear instruction power ... w/o uncore/static
  
  return  res;
}

std::ostream& operator<<(std::ostream& cout, Result res) {
	cout << "Time: " << res.time*1000.0 << " ms => " << res.timePerBlock*1000000000.0 << " ns/Block = " << (res.cyclesPerBlock) << " cycles/block | "
	     << "Energy: " << (res.power*res.time) << " J => " 
	     		   << (res.power*res.timePerBlock*1000000000.0) << " nJ/Block | "
	     << "P_Instr = " << res.power << " W";
}

int main(int argc, char * argv[]) {
  srandom(time(NULL));
  std::cout << "WARNING! Runtimes are divided by number of cores! So 0.25 cycles per instruction on 4 cores = 1 cycle/instruction/core!" << std::endl;
  start_barrier = NO_CPUs;
  stop_barrier = NO_CPUs;

  std::cout << "Calibrating ..." << std::endl;

  setupWorkload();

  std::cout << "MOV %%RCX,(%0) (Store)" << runWorkload(4,[]{ ASM_CODE("MOV %%RCX,(%0)",0xFFFFF) },0xFFFFF) << std::endl;
  std::cout << "XCHG %%R8,(%0)" << runWorkload(4,[]{ ASM_CODE("XCHG %%R8,(%0)",0xFFFF) }, 0xFFFF) << std::endl;
  std::cout << "MOV (%0),%%R8 (Load)" << runWorkload(4,[]{ ASM_CODE("MOV (%0),%%R8",0xFFFFF) },0xFFFFF) << std::endl;

  std::cout << "L_MOV %%RCX,(%0) (Store)" << runWorkload(4,[]{ ASM_CODE("MOV %%RCX,(%1)",0xFFFFF) },0xFFFFF) << std::endl;
  std::cout << "L_XCHG %%R8,(%0)" << runWorkload(4,[]{ ASM_CODE("XCHG %%R8,(%1)",0xFFFF) }, 0xFFFF) << std::endl;
  std::cout << "L_MOV (%0),%%R8 (Load)" << runWorkload(4,[]{ ASM_CODE("MOV (%1),%%R8",0xFFFFF) },0xFFFFF) << std::endl;
  
  return 0;
}
