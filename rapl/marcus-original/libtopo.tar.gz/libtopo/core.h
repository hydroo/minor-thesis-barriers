#ifndef CORE_H
#define CORE_H

class Core;

#include "thread.h"
#include <vector>

class Core
{
friend class Topology;
private:
	int id;
	std::vector<Thread*> threads;
	void attachThread(Thread* thread);
public:
	Core(int _id);
	unsigned getId();
	std::vector<Thread*> getThreads();
};

#endif // CORE_H
