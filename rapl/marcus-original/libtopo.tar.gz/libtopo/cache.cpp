#include "cache.h"

//h#define NDEBUG

#include "topology.h"
#include <assert.h>
#include <sstream>
#include <fstream>
#include <iostream>

Cache::Cache(unsigned cpu, unsigned index) : reference_cpu(cpu), cache_index(index)
{
	std::stringstream sharingCPUfile, cacheLevel, base, cacheSets, cacheWays, cacheLine, cacheType;
	base << "/sys/devices/system/cpu/cpu" << cpu<< "/cache/index" << index << "/";
	sharingCPUfile << base.str() << "shared_cpu_list";
	cacheLevel << base.str() << "level";
	cacheSets << base.str() << "number_of_sets";
	cacheWays << base.str() << "ways_of_associativity";
	cacheLine << base.str() << "coherency_line_size";
	cacheType << base.str() << "type";
	sharingThreadIDs = Topology::fileToVector(sharingCPUfile.str());
	level = Topology::fileToUnsigned(cacheLevel.str());
	sets = Topology::fileToUnsigned(cacheSets.str());
	ways = Topology::fileToUnsigned(cacheWays.str());
	lineSize = Topology::fileToUnsigned(cacheLine.str());
	std::ifstream typefile;
	typefile.open(cacheType.str().c_str(),std::ios_base::in);
	if (!typefile.is_open() || !typefile.good()) {
		std::cerr << "Failed to read cache type from " << cacheType.str() << std::endl;
		return;
	}
	switch (typefile.peek()) {
		case 'U': type = UNIFIED; break;
		case 'D': type = DATA; break;
		case 'I': type = INSTRUCTION; break;
		default: type = UNKNOWN;
	}
}

std::ostream& operator<<(std::ostream &strm, const Cache &c) {
	return strm << "Created Cache index " << c.cache_index << " on CPU " << c.reference_cpu<< std::endl
				<< "Level: " << c.level << std::endl
				<< "Line Size: " << c.lineSize << std::endl
				<< "Ways: " << c.ways << std::endl
				<< "Sets: " << c.sets << std::endl
				<< "Size: " << (c.ways*c.sets*c.lineSize)/1024 << "KB" << std::endl;
		switch (c.type) {
		   case UNIFIED: strm << "UNIFIED Cache"; break;
		   case DATA: strm << "DATA Cache"; break;
		   case INSTRUCTION: strm << "INSTRUCTION Cache"; break;
		   case UNKNOWN: strm << "UNKNOWN (!) Cache"; break;
	   }
	   strm << std::endl;

}

unsigned Cache::getLevelNum() {
	return level;
}

unsigned Cache::getLineSize() {
	return lineSize;
}

unsigned Cache::getSetsNum() {
	return sets;
}

unsigned Cache::getWaysNum() {
	return ways;
}

CacheType Cache::getType() {
	return type;
}

unsigned Cache::getSize() {
	return ways*sets*lineSize;
}

unsigned Cache::getReferenceCPU() {
	return reference_cpu;
}

void Cache::setSharingThreads(std::vector<Thread *> sharingThreads) {
	this->sharingThreads = sharingThreads;
}

std::vector<unsigned> Cache::getSharingThreadIDs() {
	return sharingThreadIDs;
}

std::vector<Thread*> &Cache::getSharingThreads() {
	return sharingThreads;
}
