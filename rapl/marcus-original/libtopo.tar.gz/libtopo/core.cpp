#include "core.h"

Core::Core(int _id) :  id(_id)
{
}

void Core::attachThread(Thread *thread) {
	threads.push_back(thread);
}

unsigned Core::getId() {
	return id;
}

std::vector<Thread*> Core::getThreads() {
	return threads;
}
