#include "perfevent.h"
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <iostream>
#include <errno.h>

#include <string.h>

const Event HWEvents::CPU_CYCLES(PerfType::HARDWARE, PERF_COUNT_HW_CPU_CYCLES);
const Event HWEvents::INSTRUCTIONS(PerfType::HARDWARE, PERF_COUNT_HW_INSTRUCTIONS);
const Event HWEvents::CACHE_REFERENCES(PerfType::HARDWARE,PERF_COUNT_HW_CACHE_REFERENCES);
const Event HWEvents::CACHE_MISSES(PerfType::HARDWARE, PERF_COUNT_HW_CACHE_MISSES);
const Event HWEvents::BRANCH_INSTRUCTIONS(PerfType::HARDWARE, PERF_COUNT_HW_BRANCH_INSTRUCTIONS);
const Event HWEvents::BRANCH_MISSES(PerfType::HARDWARE, PERF_COUNT_HW_BRANCH_MISSES);
const Event HWEvents::BUS_CYCLES(PerfType::HARDWARE, PERF_COUNT_HW_BUS_CYCLES);
const Event HWEvents::STALLED_CYCLES_FRONTEND(PerfType::HARDWARE, PERF_COUNT_HW_STALLED_CYCLES_FRONTEND);
const Event HWEvents::STALLED_CYCLES_BACKEND(PerfType::HARDWARE, PERF_COUNT_HW_STALLED_CYCLES_BACKEND);
const Event HWEvents::REF_CPU_CYCLES(PerfType::HARDWARE, PERF_COUNT_HW_REF_CPU_CYCLES);

Event CacheEvent::create(CacheID t, Operation o, Result r) {
	int num ;
	switch (r) {
		case Result::Access: num = PERF_COUNT_HW_CACHE_RESULT_MISS; break;
		default: num = PERF_COUNT_HW_CACHE_RESULT_MISS;
	}
	num <<= 8;
	switch (o) {
		case Operation::Read: num |= PERF_COUNT_HW_CACHE_OP_READ; break;
		case Operation::Write: num |= PERF_COUNT_HW_CACHE_OP_WRITE; break;
		default: num |= PERF_COUNT_HW_CACHE_OP_PREFETCH;
	}
	num <<= 8;
	switch (t) {
		case CacheID::L1D: num |= PERF_COUNT_HW_CACHE_L1D; break;
		case CacheID::L1I: num |= PERF_COUNT_HW_CACHE_L1I; break;
		case CacheID::LastLevel: num |= PERF_COUNT_HW_CACHE_LL; break;
		case CacheID::DTLB: num |= PERF_COUNT_HW_CACHE_DTLB; break;
		case CacheID::ITLB: num |= PERF_COUNT_HW_CACHE_ITLB; break;
		case CacheID::BPU: num |= PERF_COUNT_HW_CACHE_BPU; break;
		case CacheID::NODE: num |= PERF_COUNT_HW_CACHE_NODE; break;
		default: num |= PERF_COUNT_HW_CACHE_NODE;
	}
	return Event(PerfType::CACHE, num);
}

PerfEvent::PerfEvent(Event ev) : value(0), rate(0), lastTime(0)
{
	//attr.type must be set in the inherited classes!
	memset(&attr, 0, sizeof(struct perf_event_attr));
	attr.size = sizeof(perf_event_attr);
	//attr.config must be set in the inherited classses!
	attr.sample_period = 0; //no default sampling
	attr.sample_type =  0; //Sample nothing
	attr.read_format = PERF_FORMAT_TOTAL_TIME_ENABLED |
					   PERF_FORMAT_TOTAL_TIME_RUNNING; //enable multiplexing
	attr.inherit = 1;	//we want to monitor the peformance of all children!
	attr.inherit_stat = 1; //yes, counter saveing/restoring enabled in child
	attr.wakeup_events =1024;	//I don't know if this is a good idea
	//again, we don't care for the newer breakpoint stuff

	attr.type = ev.type;
	attr.config = ev.config;
	attr.config1 = ev.config1;
	attr.config2 = ev.config2;

	enabled = false;
	perf_fd = -1;
}

PerfEvent::~PerfEvent() {
	for (auto it = thresholds.begin(); it != thresholds.end(); it++) {
		delete *it;
	}
}

bool PerfEvent::startMonitor() {
	//pid = 0 --> monitor this thread, cpu == -1 --> on all CPUs
	//we may use event groups here in the future. group them all together for now each is a new group (-1)
	perf_fd = syscall(__NR_perf_event_open,&attr,0,-1,-1,0);
	enabled = !attr.disabled;
	if (perf_fd < 0) {
		std::cerr << "Error: " << perf_fd << " Errno: " << errno;
		return false;
	}
	ioctl(perf_fd,PERF_EVENT_IOC_RESET,0);
	return true;
}

void PerfEvent::setEnabled(bool status) {
	if (perf_fd < 0) return;
	if (enabled == status) return;
	enabled = status;
	if (status)
		ioctl(perf_fd,PERF_EVENT_IOC_ENABLE);
	else
		ioctl(perf_fd,PERF_EVENT_IOC_DISABLE);
}

bool PerfEvent::isEnabled() {
	return enabled;
}

void PerfEvent::resetCtr() {
	if (perf_fd < 0) return;
	ioctl(perf_fd,PERF_EVENT_IOC_RESET);
}

void PerfEvent::refreshValues() {

	if (perf_fd < 0) { //not opened yet!
		value = 0;
		return;
	}

	ioctl(perf_fd,PERF_EVENT_IOC_REFRESH);
	ssize_t r;

	if ((r = read(perf_fd,&last_value,sizeof(uint64_t)*3)) != sizeof(uint64_t)*3 || r == -1) {
		std::cerr << "Error reading counter!";
		if (r == -1) std::cerr << " The error code was: " << strerror(errno);
		std::cerr << std::endl;
		value = -1;
	}
	if (last_value[2] == 0) {
		//std::cerr << " The counter did not ever run :/ Can not estimate anything." << std::endl;
		value = 0;
		return;
	}
	value = (last_value[0]*last_value[1])/last_value[2];
}

uint64_t PerfEvent::readCtr() {
	refreshValues();
	return value;
}

bool PerfEvent::hasBeenMultiplexed() {
	return (last_value[1] != last_value[2]);
}

uint64_t PerfEvent::getRate() {
	return rate;
}

float PerfEvent::getConfidence() {
	ioctl(perf_fd,PERF_EVENT_IOC_REFRESH);
	ssize_t r;
	if ((r = read(perf_fd,&last_value,sizeof(uint64_t)*3)) != sizeof(uint64_t)*3)
		if (r == -1)
			return errno;
	return ((float)last_value[2]*100)/last_value[1];
}

void PerfEvent::checkThresholds() {
	timeval time;
	gettimeofday(&time,nullptr);
	uint64_t curTime = (time.tv_sec * 1000000) + (time.tv_usec); //ns
	for (auto it = thresholds.begin(); it != thresholds.end(); it++) {
		notify_thrs *t = *it;
//		std::cerr << "Rate is: " << rate << std::endl;
		switch (t->type) {
			case ThrsType::VALUE:
				if (t->dir == ThrsDirection::HIGHER) {
					if (value >= t->thrs) t->notifier(this);
				} else {
					if (value < t->thrs) t->notifier(this);
				}

				break;
			case ThrsType::RATE:
				if (t->dir == ThrsDirection::HIGHER) {
					if (rate >= t->thrs) t->notifier(this);
				} else {
					if (rate < t->thrs) t->notifier(this);
				}
				break;
			case ThrsType::INTERVAL:
				if (t->thrs > curTime) {
					t->thrs += t->interval;
					t->notifier(this);
				};
				break;
		}
	}
}

void PerfEvent::notifyEventThresholdRate(int64_t threshold,std::function<void (PerfEvent*)> fkt) {
	if  ( threshold > 0)
		thresholds.push_back(new notify_thrs(threshold, ThrsType::RATE, ThrsDirection::HIGHER, fkt));
	else
		thresholds.push_back(new notify_thrs(std::abs(threshold), ThrsType::RATE, ThrsDirection::LOWER, fkt));
}

void PerfEvent::notifyEventThresholdValue(int64_t threshold, std::function<void (PerfEvent *)> fkt) {
	if  ( threshold > 0)
		thresholds.push_back(new notify_thrs(threshold, ThrsType::VALUE, ThrsDirection::HIGHER, fkt));
	else
		thresholds.push_back(new notify_thrs(std::abs(threshold), ThrsType::VALUE, ThrsDirection::LOWER, fkt));
}

void PerfEvent::notifyEventThresholdInterval(int64_t interval, std::function<void (PerfEvent *)> fkt) {
	timeval time;
	gettimeofday(&time,nullptr);
	uint64_t curTime = (time.tv_sec * 1000000) + (time.tv_usec); //ns
	thresholds.push_back(new notify_thrs(interval, curTime+interval, fkt));
}


//This also updates the rate
void PerfEvent::update() {
	timeval time;
	//refreshValues();
	gettimeofday(&time,nullptr);
	uint64_t curTime = (time.tv_sec * 1000000) + (time.tv_usec); //ns
	refreshValues();
	//Read the counter ... however we do that
//	value = readCtr();
	//calculate RATE in 1/s
//	std::cerr << "cur_time - last_time: " << (curTime-lastTime) << std::endl;
//	std::cerr << "value, prev_value: " << value << ", " << prev_value << std::endl;
	rate = (value - prev_value)*1000000LL/(curTime-lastTime);
	lastTime = curTime;
	prev_value = value;
	checkThresholds();
}
