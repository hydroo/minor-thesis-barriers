#include "topology.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>
#include <dirent.h>
#include <sched.h>

Topology::Topology()
{
	std::vector<unsigned> present = fileToVector("/sys/devices/system/cpu/present");
	std::cout << "Populating with " << present.size() << " Threads ..." << std::endl;

	for (auto it = present.begin(); it != present.end(); it++) {
		Thread* t = new Thread(*it);
		attachThread(t);
	}

	//we can only add caches, after all treads are accounted for else we don't know where
	//to attach the caches
	DIR *dp;
	struct dirent *dirp;

	for (auto it = present.begin(); it != present.end(); it++) {
		//Installing caches ...
		std::stringstream cachedir;
		cachedir << "/sys/devices/system/cpu/cpu" << *it <<  "/cache";
		dp = opendir(cachedir.str().c_str());

		if (dp == NULL) {
			std::cerr << "ERROR: No cache directory. Is the kernel configured correctly?" << std::endl;
			return;
		}

		while ((dirp = readdir(dp))) {
			//process the new directory
			if (dirp->d_type != DT_DIR) continue;
			std::stringstream dirname(dirp->d_name);
			if (dirname.str().compare(0,5,"index",5)) continue; //only index dirs!
			dirname.ignore(5);
			int index;
			dirname >> index;
			attachCache(new Cache(*it,index));
		}
	}
}

unsigned Topology::fileToUnsigned(std::string filename) {
	std::vector<unsigned> res = fileToVector(filename);
	assert(res.size() == 1);
	return res[0];
}

std::vector<unsigned> Topology::fileToVector(std::string filename) {
	std::ifstream cpufile;
	std::string line;
	std::vector<unsigned> result;

	cpufile.open(filename.c_str(), std::ios_base::in);
	if (!cpufile.is_open() || !cpufile.good()) {
		std::cerr << filename << " could not be read" << std::endl;
		return std::vector<unsigned>();
	}

	unsigned a = 0,b = 0;
	//only read the first line. TODO: is this enough?
	std::getline(cpufile,line);
	std::stringstream ss(line);
	while (!ss.eof()) {
		ss >> a;

		if (ss.peek() == '-') {
			ss.ignore();
			ss >> b;
		} else {
			b = a;
		}
		for (unsigned i = a; i <= b; i++) {
			result.push_back(i);
		}
		if (ss.eof()) break;

		if (ss.peek() == ',') {
			ss.ignore();
		} else {
			std::cerr << "ERROR! Wrongly formated cpu string!" << std::endl;
			return std::vector<unsigned>();
		}
	}
	return result;
}

Topology::~Topology() {
	while (!threads.empty()) {
		delete threads.back();
		threads.pop_back();
	}
	while (!cls.empty()) {
		delete cls.back();
		cls.pop_back();
	}
}

void Topology::attachThread(Thread *t) {
	threads.push_back(t);
	if (t->getCoreId() >= cores.size()) {
		for (unsigned i = cores.size(); i <= t->getCoreId();i++) {
			cores.push_back(new Core(i));
		}
	}

	cores[t->getCoreId()]->attachThread(t);
	t->setCore(cores[t->getCoreId()]);

	if (t->getSocketId() >= sockets.size()) {
		for (unsigned i = sockets.size(); i <= t->getSocketId(); i++) {
			sockets.push_back(new Socket(i));
		}
	}

	sockets[t->getSocketId()]->attachThread(t);
	t->setSocket(sockets[t->getSocketId()]);
}

void Topology::attachCache(Cache *c) {

	std::vector<Thread*> sharing;
	auto stids = c->getSharingThreadIDs();
	for (auto sti = stids.begin(); sti != stids.end(); sti++) {
			sharing.push_back(threads[*sti]);
	}

	c->setSharingThreads(sharing);

	auto tids = c->getSharingThreadIDs();
	for (auto it = tids.begin(); it != tids.end(); it++) {
		assert(*it < threads.size());
		if (!threads[*it]->hasCache(c))
			threads[*it]->addCache(c);
	}
}

std::vector<Thread*> &Topology::getThreads() {
	return threads;
}

std::vector<Core*> &Topology::getCores() {
	return cores;
}

std::vector<Socket*> &Topology::getSockets() {
	return sockets;
}

Thread& Topology::getCurrentThread() {
	return *(threads[sched_getcpu()]);
}

Socket& Topology::getCurrentSocket() {
	return *(getCurrentThread().getSocket());
}

Core& Topology::getCurrentCore() {
	return *(getCurrentThread().getCore());
}
