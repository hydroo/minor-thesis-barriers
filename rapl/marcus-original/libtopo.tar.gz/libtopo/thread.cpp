#include <iostream>
#include "thread.h"
#include <sstream>
#include "topology.h"
#include <assert.h>
#include "cache.h"

Thread::Thread(unsigned i) : id(i), cs_init(false), ts_init(false)
{
	std::ostringstream base, score, ssocket, cachedir;
	base << "/sys/devices/system/cpu/cpu" << i <<  "/";
	score << base.str() << "topology/core_id";
	ssocket << base.str() << "topology/physical_package_id";
	cachedir << base.str() << "cache";
	std::vector<unsigned> core = Topology::fileToVector(score.str());
	std::vector<unsigned> socket = Topology::fileToVector(ssocket.str());
	assert(core.size() == 1);
	assert(socket.size() == 1);
	socket_id = socket.front();
	core_id = core.front();
	threads.push_back(this);
}

unsigned Thread::getCoreId() {
	return core_id;
}

unsigned Thread::getSocketId() {
	return socket_id;
}

unsigned Thread::getId() {
	return id;
}

void Thread::setCore(Core *c) {
	core = c;
}

Socket* Thread::getSocket() {
	return socket;
}

Core* Thread::getCore() {
	return core;
}

bool Thread::hasCache(Cache *c) {
	for (auto it = cacheLevels.begin(); it != cacheLevels.end(); it++) {
		if ( c->getLevelNum() == (*it)->getLevelNum() &&
			 c->getType() == (*it)->getType()) return true;
	}
	return false;
}

void Thread::setSocket(Socket *s) {
	socket = s;
}

void Thread::addCache(Cache *c) {
	cacheLevels.push_back(c);
}

std::vector<Cache*>& Thread::getCaches() {
	return cacheLevels;
}

std::vector<Thread*> &Thread::getThreads() {
	return threads;
	std::cerr << "Threads!" << threads.size() << std::endl;
}
