#ifndef CACHELEVEL_H
#define CACHELEVEL_H

class CacheLevel;

#include "cache.h"
#include <vector>

class CacheLevel
{
friend class Topology;
private:
	unsigned level;
	void addCache(Cache* c);
	std::vector<Cache*> caches;
public:
	unsigned getLevel();
	CacheLevel(unsigned lvl);
};

#endif // CACHELEVEL_H
