#include "cachelevel.h"

CacheLevel::CacheLevel(unsigned lvl) : level(lvl)
{
}

unsigned CacheLevel::getLevel() {
	return level;
}


