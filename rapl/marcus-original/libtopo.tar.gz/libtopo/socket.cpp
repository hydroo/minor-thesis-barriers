#include "socket.h"

Socket::Socket(unsigned _id) : id(_id)
{
}

void Socket::attachThread(Thread *t) {
	threads.push_back(t);
}

unsigned Socket::getId() {
	return id;
}

std::vector<Thread*> Socket::getThreads() {
	return threads;
}
