#include "monitor.h"

#include <sched.h>
#include <iostream>

Monitor::Monitor(uint64_t interval_ms) {
	notify_ms = interval_ms;
}

void Monitor::runThread() {
	//now monitor every ms millis
	runs = 0;
	timeval t;
	gettimeofday(&t,NULL);
	start_time = t.tv_sec*1000000LL+t.tv_usec;
	while (simple_lock) {
		runs++;
		int64_t timetarget = start_time+runs*notify_ms*1000LL;
		gettimeofday(&t,NULL);
		int64_t slTime = std::max(timetarget-(t.tv_sec*1000000LL+t.tv_usec),0LL);
		usleep(slTime);
		for (auto it = events.begin(); it != events.end(); it++) {
			PerfEvent *ev = *it;
			if (ev->isEnabled())
				ev->update();
		}
	}
}

void *Monitor::run(void *ptr) {
	Monitor* m = (Monitor*)ptr;
	m->runThread();
	return NULL;
}

bool Monitor::startMonitor() {
	simple_lock = true;
	for (auto it : events) {
		if (!it->startMonitor()) return false;
	}
	pthread_create(&thread,nullptr,run, this);
	pthread_yield();
	return true;
}

void Monitor::cancelMonitor() {
	pthread_cancel(thread);
	simple_lock = false;
}

void Monitor::stopMonitor() {
	//TODO: Error handling
	simple_lock = false;
	pthread_join(thread,NULL);
}

void Monitor::setIntervall(int ms) {
	if (simple_lock)
		return; //Can not modify while running!
	notify_ms = ms;
}

void Monitor::addEvent(PerfEvent *ev) {
	events.push_back(ev);
}
